# @aws-sdk/abort-controller

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/abort-controller/latest.svg)](https://www.npmjs.com/package/@aws-sdk/abort-controller)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/abort-controller.svg)](https://www.npmjs.com/package/@aws-sdk/abort-controller)
